# 混合版本 SET CONFIGURATION 部分应用复现（2026-11-10）

## 环境
- 3C5D：CN8/9 = 2.0.13.1 RC1 ab6d3de；CN10 = 2.0.12.1 RC12 c05111d；DN11-15 = 2.0.13.1
- 干净数据目录，集群名 ClusterID_mix

## 复现步骤
1. 执行 `SET CONFIGURATION 'data_region_group_extension_policy'='PROACTIVE';`
2. 记录返回（03_set_result.txt）
3. `SHOW CONFIGURATION`（04_config_after.txt）与 `SHOW CONFIGURATION ON 0/1/2`（05_config_on_*.txt）
4. 建库 root.mix1，写 9 个不同 slot，观察组数（06_behavior.txt）

## 观察
- 客户端返回 301 `DataRegionGroupExtensionPolicy PROACTIVE doesn't exist.`
- 新 CN 的 SHOW CONFIGURATION 已显示 PROACTIVE，旧 CN 未生效
- 后续扩容按 PROACTIVE 行为执行

## 日志
- logs/cn_8、cn_9：2.0.13.1 ConfigNode 日志
- logs/cn_10_rc12：2.0.12.1 ConfigNode 日志
- logs/dn_11~15：DataNode 日志

## 关键证据
- 03_set_result.txt：客户端 301 `PROACTIVE doesn't exist`
- 04_config_after.txt：data 策略已变 PROACTIVE
- 05_config_on_0/1/2.txt：node0/1=PROACTIVE，node2(2.0.12.1)=AUTO
- 06_behavior.txt：新库 9 slot 建到 data=7（PROACTIVE 行为）
- 07_config_files.txt：CN8/9 配置文件已写 PROACTIVE，CN10 仍 AUTO
- 08_log_evidence.txt：CN8/9 有配置更新与策略表重平衡日志，CN10 无更新日志（拒绝发生在文件写入前）
